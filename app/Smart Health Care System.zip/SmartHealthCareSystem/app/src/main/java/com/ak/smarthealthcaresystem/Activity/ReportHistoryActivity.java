package com.ak.smarthealthcaresystem.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.ak.smarthealthcaresystem.R;

public class ReportHistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_history);
    }
}